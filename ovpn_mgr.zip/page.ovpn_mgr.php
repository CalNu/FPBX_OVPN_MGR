<?php
if (!defined('FREEPBX_IS_AUTH')) { die('No direct script access allowed'); }

// ============================================================================
// Paths
// ============================================================================
$ampWebRoot  = rtrim($amp_conf['AMPWEBROOT'] ?? '/var/www/html', '/');
$baseDir     = "{$ampWebRoot}/PhoneSettings/openvpn";
$pkgDir      = "{$ampWebRoot}/PhoneSettings/vpnkeys";
$pkiDir      = "{$baseDir}/legacy_pki";
$logFile     = "{$baseDir}/logs/openvpn.log";
$serverConf  = "{$baseDir}/legacy-vpn.conf";
$crlFile     = "{$pkiDir}/crl.pem";
$pidFile     = "{$baseDir}/openvpn.pid";
$serverKey   = "{$pkiDir}/private/server.key";
$moduleRoot  = __DIR__;
$ovpnctl     = "{$moduleRoot}/scripts/ovpnctl";
$setupScript = "{$moduleRoot}/scripts/setup-root.sh";

// ============================================================================
// CSRF token - one per session, required on every state-changing request.
// ============================================================================
if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
if (empty($_SESSION['ovpn_mgr_csrf'])) {
    $_SESSION['ovpn_mgr_csrf'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['ovpn_mgr_csrf'];

// PHP's date()/time() use whatever date.timezone is set in php.ini - on
// many boxes that's UTC regardless of the system's actual configured
// timezone, which is why timestamps (log separators, package/cert dates)
// could show the wrong local time. Align PHP to the system's real
// timezone once, so every date() call below is correct.
if (!function_exists('ovpn_mgr_detect_system_timezone')) {
    function ovpn_mgr_detect_system_timezone() {
        if (file_exists('/etc/timezone')) {
            $tz = trim((string)@file_get_contents('/etc/timezone'));
            if ($tz !== '' && @timezone_open($tz) !== false) {
                return $tz;
            }
        }
        $tzOut = trim((string)@shell_exec('timedatectl show -p Timezone --value 2>/dev/null'));
        if ($tzOut !== '' && @timezone_open($tzOut) !== false) {
            return $tzOut;
        }
        return null;
    }
}
$ovpnMgrSystemTz = ovpn_mgr_detect_system_timezone();
if ($ovpnMgrSystemTz) {
    date_default_timezone_set($ovpnMgrSystemTz);
}

function csrf_require() {
    global $csrfToken;
    $sent = $_POST['csrf_token'] ?? '';
    if (!hash_equals($csrfToken, (string)$sent)) {
        http_response_code(403);
        die('Security check failed (invalid or expired form token). Please reload the page and try again.');
    }
}

// ============================================================================
// Helper Functions (pure computation - no shell, no privilege)
// ============================================================================
function reqIpsToNetmask($reqIps) {
    $needed = intval($reqIps) + 3; // network, gateway, broadcast
    $bits = 32 - ceil(log($needed, 2));
    if ($bits < 16) { $bits = 16; }
    if ($bits > 29) { $bits = 29; }
    $mask = (0xFFFFFFFF << (32 - $bits)) & 0xFFFFFFFF;
    return long2ip($mask);
}

// Direct CIDR-prefix -> netmask conversion, used by the settings form
// (which now takes a CIDR prefix directly instead of a "how many IPs do
// you need" capacity estimate - same clamp range as reqIpsToNetmask so
// existing saved configs still round-trip the same way).
function cidrToNetmask($cidr) {
    $cidr = intval($cidr);
    if ($cidr < 16) { $cidr = 16; }
    if ($cidr > 29) { $cidr = 29; }
    $mask = (0xFFFFFFFF << (32 - $cidr)) & 0xFFFFFFFF;
    return long2ip($mask);
}

function netmaskToReqIps($netmask) {
    $long = ip2long($netmask);
    if ($long === false) { return 250; }
    $base = sprintf("%b", $long);
    $cidr = substr_count($base, '1');
    $hostBits = 32 - $cidr;
    return ($hostBits > 1) ? (pow(2, $hostBits) - 3) : 1;
}

function calculateSubnetDetails($hostIp, $netmask) {
    $longHost = ip2long($hostIp);
    $longMask = ip2long($netmask);

    if ($longHost === false || $longMask === false) {
        return [
            'valid' => false,
            'is_network_or_bcast' => false,
            'net_ip' => '10.8.0.0',
            'suggested_first' => '10.8.0.1',
            'suggested_prev_last' => '10.8.0.254',
            'range_start' => '10.8.0.1',
            'range_end' => '10.8.0.254',
            'is_first_host' => true,
            'cidr' => 24,
        ];
    }

    $longNet = $longHost & $longMask;
    $broadcastLong = $longNet | (~$longMask & 0xFFFFFFFF);

    $isNetwork = ($longHost === $longNet);
    $isBroadcast = ($longHost === $broadcastLong);
    $isInvalid = ($isNetwork || $isBroadcast);

    $firstUsable = $longNet + 1;
    $lastUsable = $broadcastLong - 1;
    $prevBlockLastUsable = $longNet - 2;

    $cidrBits = 32 - strlen(rtrim(decbin(($longMask ^ 0xFFFFFFFF) & 0xFFFFFFFF), '0'));
    $cidrBits = max(0, min(32, 32 - substr_count(decbin((~$longMask) & 0xFFFFFFFF), '1')));

    return [
        'valid' => true,
        'is_network_or_bcast' => $isInvalid,
        'net_ip' => long2ip($longNet),
        'suggested_first' => long2ip($firstUsable),
        'suggested_prev_last' => long2ip($prevBlockLastUsable),
        'range_start' => long2ip($firstUsable),
        'range_end' => long2ip($lastUsable),
        'is_first_host' => ($longHost === $firstUsable),
        'cidr' => $cidrBits,
    ];
}

// Strict validation for anything that ends up written into the OpenVPN
// server config file. Rejecting control characters here is what closes
// the config-injection hole: without this, a newline in a form field
// could add arbitrary directives to a config that later gets loaded by
// a root-owned process.
function isValidHostOrIp($s) {
    if (!is_string($s) || $s === '' || strlen($s) > 253) { return false; }
    if (preg_match('/[\x00-\x1F\x7F]/', $s)) { return false; } // no control chars/newlines
    if (filter_var($s, FILTER_VALIDATE_IP)) { return true; }
    return (bool) preg_match('/^(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\.(?!-)[A-Za-z0-9-]{1,63}(?<!-))*$/', $s);
}

function tailFile($path, $lines = 200, $maxBytes = 2000000) {
    if (!file_exists($path)) { return ''; }
    $size = filesize($path);
    if ($size <= $maxBytes) {
        $content = (string)@file_get_contents($path);
    } else {
        $fp = @fopen($path, 'r');
        if (!$fp) { return ''; }
        fseek($fp, -$maxBytes, SEEK_END);
        $content = (string)fread($fp, $maxBytes);
        fclose($fp);
    }
    $arr = explode("\n", $content);
    return implode("\n", array_slice($arr, -$lines));
}

function getOpenVpnVersion() {
    // Reading --version needs no privilege at all - no sudo here.
    $openvpnBin = file_exists('/usr/sbin/openvpn') ? '/usr/sbin/openvpn' : '/usr/local/sbin/openvpn';
    exec(escapeshellarg($openvpnBin) . " --version 2>&1", $output);
    if (!empty($output[0]) && preg_match('/OpenVPN\s+([0-9]+\.[0-9]+\.[0-9]+)/i', $output[0], $matches)) {
        return $matches[1];
    }
    return '2.4.0';
}

function hasOvpnctlAccess($ovpnctl) {
    exec('sudo -n ' . escapeshellarg($ovpnctl) . ' check 2>&1', $out, $rc);
    return ($rc === 0);
}

// ============================================================================
// Standalone-firewall fallback - used only when FreePBX's Firewall module
// isn't present (a plain FreePBX-on-Debian/Ubuntu install with nothing
// but stock iptables, no Sysadmin/Firewall). Delegates to ovpnctl's
// port-sync subcommand (see scripts/ovpnctl), which maintains a
// dedicated 'ovpn_mgr' chain jumped from INPUT - it never touches any
// other chain, rule, or the box's default policy, and doesn't require
// guessing at nftables/ufw/firewalld conventions on top of iptables.
// Requires the one-time root setup (scripts/setup-root.sh) that's
// already required for start/stop/NAT on non-Distro systems.
function syncOvpnFirewallPortRuleStandalone($port, $logFile, $ovpnctl) {
    $result = ['written' => false, 'reloaded' => false, 'message' => ''];

    exec('sudo -n ' . escapeshellarg($ovpnctl) . ' port-sync ' . escapeshellarg($port) . ' 2>&1', $out, $rc);

    $result['written']  = ($rc === 0);
    $result['reloaded'] = ($rc === 0);

    @file_put_contents(
        $logFile,
        "\n[FIREWALL SYNC " . date('Y-m-d H:i:s') . "] Standalone iptables fallback: ovpnctl port-sync {$port}, exit={$rc}\n"
            . implode("\n", $out) . "\n",
        FILE_APPEND
    );

    if ($rc !== 0) {
        $result['message'] = "Could not open UDP/{$port} via the standalone iptables fallback (ovpnctl port-sync exited {$rc}). "
            . "This needs the one-time root setup: run 'sudo bash " . dirname($ovpnctl) . "/setup-root.sh' once from a root "
            . "shell, which grants this module narrow, script-scoped sudo access (the same access start/stop/NAT already "
            . "need on a standalone box). Details logged to the OpenVPN log.";
    }

    return $result;
}

// ============================================================================
// Firewall port sync - uses FreePBX's own "Custom Services" feature
// (Connectivity > Firewall > Custom Services), the same mechanism behind
// the addCustomService()/editCustomService()/getAllCustomServices() methods
// confirmed in FreePBX/firewall's Firewall.class.php. This replaced an
// earlier approach that wrote directly into /etc/firewall-4.rules (the
// file behind Advanced Settings > Custom Firewall Rules) - that file is
// only consulted when the "Custom Firewall Rules" toggle is turned on,
// which FreePBX deliberately ships OFF ("This should be Disabled unless
// you explicitly know why it is enabled"), and there's no confirmed way
// to flip that toggle from code. Custom Services doesn't have that
// gate - it's the box checked/visible by default in the Firewall GUI,
// and does not require the "Custom Firewall Rules" switch at all.
//
// On a standalone (non-Distro) system where the Firewall module isn't
// present at all, this falls back to syncOvpnFirewallPortRuleStandalone()
// below, which manages a dedicated 'ovpn_mgr' iptables chain instead.
//
// This is also why the previous "fwconsole firewall add/del external
// <port>" calls never worked: that subcommand only adds/removes IP/host/
// network entries to a zone (see "fwconsole firewall -help") - passing a
// bare port number to it never opened anything.
function syncOvpnFirewallPortRule($newPort, $logFile, $ovpnctl) {
    $port = intval($newPort);
    $serviceName = 'OpenVPN Manager';
    $result = ['written' => false, 'reloaded' => false, 'message' => ''];

    if (!class_exists('FreePBX')) {
        return syncOvpnFirewallPortRuleStandalone($port, $logFile, $ovpnctl);
    }

    try {
        $fw = \FreePBX::Firewall();
    } catch (Throwable $e) {
        // No Firewall module on this box at all - this is exactly the
        // "standalone, non-Distro, plain iptables" case, not an error.
        @file_put_contents(
            $logFile,
            "\n[FIREWALL SYNC " . date('Y-m-d H:i:s') . "] FreePBX Firewall module not present - using standalone iptables fallback.\n",
            FILE_APPEND
        );
        return syncOvpnFirewallPortRuleStandalone($port, $logFile, $ovpnctl);
    }

    if (!method_exists($fw, 'addCustomService') || !method_exists($fw, 'editCustomService')) {
        $result['message'] = "This FreePBX version's Firewall module doesn't expose addCustomService()/editCustomService() - "
            . "open Connectivity > Firewall > Custom Services and add/edit a UDP service on port {$port} manually.";
        @file_put_contents($logFile, "\n[FIREWALL SYNC " . date('Y-m-d H:i:s') . "] " . $result['message'] . "\n", FILE_APPEND);
        return $result;
    }

    try {
        // Find our own service by name if it already exists, so a port
        // change edits it in place instead of piling up duplicates.
        $existingId = null;
        if (method_exists($fw, 'getAllCustomServices')) {
            foreach ((array)$fw->getAllCustomServices() as $key => $svc) {
                $svcArr = (array)$svc;
                $svcName = $svcArr['name'] ?? $svcArr['n'] ?? '';
                if ($svcName === $serviceName) {
                    $existingId = $svcArr['id'] ?? $key;
                    break;
                }
            }
        }

        if ($existingId !== null) {
            $fw->editCustomService($existingId, $serviceName, 'udp', $port);
        } else {
            $fw->addCustomService($serviceName, 'udp', $port);
        }
        $result['written'] = true;
    } catch (Throwable $e) {
        $result['message'] = "Error calling the Firewall module's Custom Service API: " . $e->getMessage();
        @file_put_contents($logFile, "\n[FIREWALL SYNC " . date('Y-m-d H:i:s') . "] " . $result['message'] . "\n", FILE_APPEND);
        return $result;
    }

    exec('fwconsole firewall restart 2>&1', $restartOut, $restartRc);
    $result['reloaded'] = ($restartRc === 0);
    @file_put_contents(
        $logFile,
        "\n[FIREWALL SYNC " . date('Y-m-d H:i:s') . "] Synced Custom Service '{$serviceName}' to UDP/{$port}"
            . " (existingId=" . var_export($existingId, true) . "), fwconsole firewall restart exit={$restartRc}\n"
            . implode("\n", $restartOut) . "\n",
        FILE_APPEND
    );

    if (!$result['reloaded']) {
        $result['message'] = "Custom Service '{$serviceName}' was created/updated for UDP/{$port} in Firewall > Custom "
            . "Services, but 'fwconsole firewall restart' returned a non-zero exit code - it may not be active yet. "
            . "Check Connectivity > Firewall in the GUI. Details logged to the OpenVPN log.";
    } else {
        // Zone assignment (Internet/Local/Other) for a *new* custom service
        // could not be fully confirmed from source, so it isn't set
        // programmatically the first time - only surfaced here (not as a
        // failure banner) so it's not a persistent nag on every save.
        @file_put_contents(
            $logFile,
            "\n[FIREWALL SYNC NOTE] If this is the first time '{$serviceName}' was created, open Firewall > Custom "
                . "Services once and confirm its Internet/Local/Other zone toggles are set the way you want (same as "
                . "your existing services) - this module sets the port/protocol but does not assume which zones.\n",
            FILE_APPEND
        );
    }

    return $result;
}

function applyVpnRoutingAndNat($ovpnctl, $netIp, $cidrBits, $iface) {
    // Opening/closing the OpenVPN UDP port itself is handled by FreePBX's
    // own Firewall module (fwconsole firewall add/del external|internet)
    // at the call site below - that's the FreePBX-native, persistence-
    // safe way to do it and works the same regardless of host distro.
    // ovpnctl is only needed here for the two things that module can't
    // do: enabling IP forwarding and NAT/masquerade for the VPN subnet.
    exec('sudo -n ' . escapeshellarg($ovpnctl) . ' ipforward-on 2>&1');
    // Correct form is "add <zone> <id...>" - the literal word "zone" isn't
    // part of the syntax (see "fwconsole firewall -help"); the old line
    // ("add zone trusted tun+") was being silently rejected, so the tun+
    // interface was never actually placed in the trusted zone.
    exec('fwconsole firewall add trusted tun+ 2>&1');
    // "restart" is the documented subcommand that applies rule changes -
    // "sync" isn't a real fwconsole firewall subcommand and was a no-op.
    exec('fwconsole firewall restart 2>&1');

    $cidr = "{$netIp}/{$cidrBits}";
    $cmd = 'sudo -n ' . escapeshellarg($ovpnctl) . ' nat-sync ' . escapeshellarg($cidr) . ' ' . escapeshellarg($iface);
    exec($cmd . ' 2>&1');
}

function startOpenVpnServer($ovpnctl, $serverConf, $baseDir, $serverKey) {
    $logDir = "{$baseDir}/logs";
    $logFile = "{$logDir}/openvpn.log";
    $pkiDir = "{$baseDir}/legacy_pki";
    $crlFile = "{$pkiDir}/crl.pem";

    if (!file_exists($logDir)) {
        @mkdir($logDir, 0775, true);
    }

    // Log rotation - the file is owned by us (asterisk), so no sudo needed.
    if (file_exists($logFile) && filesize($logFile) > 5242880) {
        $tail = tailFile($logFile, 2000);
        @file_put_contents($logFile, $tail . "\n");
    }

    if (!file_exists($crlFile) && file_exists("{$pkiDir}/ca.crt") && file_exists("{$pkiDir}/private/ca.key")) {
        if (!file_exists("{$pkiDir}/index.txt")) { @touch("{$pkiDir}/index.txt"); }
        if (!file_exists("{$pkiDir}/crlnumber")) { @file_put_contents("{$pkiDir}/crlnumber", "01\n"); }

        $tmpCnf = "{$pkiDir}/crl_openssl.cnf";
        $cnfData = "[ ca ]\ndefault_ca = CA_default\n\n[ CA_default ]\ndir = {$pkiDir}\ndefault_md = sha256\n";
        @file_put_contents($tmpCnf, $cnfData);

        exec("OPENSSL_CONF=" . escapeshellarg($tmpCnf) . " openssl ca -gencrl -keyfile " . escapeshellarg("{$pkiDir}/private/ca.key") . " -cert " . escapeshellarg("{$pkiDir}/ca.crt") . " -out " . escapeshellarg($crlFile) . " -config " . escapeshellarg($tmpCnf) . " 2>&1");
        @unlink($tmpCnf);
    }

    $installedVersion = getOpenVpnVersion();
    $isLegacy = version_compare($installedVersion, '2.5.0', '<');

    if (file_exists($serverConf)) {
        $lines = explode("\n", (string)@file_get_contents($serverConf));
        $cleanLines = [];
        foreach ($lines as $line) {
            $trimmed = trim($line);
            if (strpos($trimmed, 'crl-verify') === 0 && !file_exists($crlFile)) {
                continue;
            }
            if ($isLegacy) {
                if (strpos($trimmed, 'data-ciphers') === 0 || strpos($trimmed, 'data-ciphers-fallback') === 0 ||
                    strpos($trimmed, 'providers') === 0 || strpos($trimmed, 'ignore-unknown-option') === 0) {
                    continue;
                }
            } else {
                if (strpos($trimmed, 'ncp-disable') === 0) {
                    continue;
                }
            }
            $cleanLines[] = $line;
        }
        $cleanContent = implode("\n", $cleanLines);

        if ($isLegacy) {
            if (strpos($cleanContent, 'cipher ') === false) {
                $cleanContent .= "\ncipher AES-128-CBC\n";
            }
        } else {
            if (strpos($cleanContent, 'data-ciphers ') === false) {
                $cleanContent .= "\ndata-ciphers AES-256-GCM:AES-128-GCM:AES-128-CBC:CHACHA20-POLY1305\n";
            }
        }
        if (strpos($cleanContent, 'verb ') === false) {
            $cleanContent .= "\nverb 3\n";
        }
        @file_put_contents($serverConf, $cleanContent);
    }

    if (file_exists($serverKey)) {
        @chmod($serverKey, 0600);
    }

    exec('sudo -n ' . escapeshellarg($ovpnctl) . ' start 2>&1', $output, $returnCode);
    if ($returnCode !== 0 && !empty($output)) {
        @file_put_contents($logFile, "\n[GUI START ATTEMPT Exit Code: {$returnCode}]\n" . implode("\n", $output) . "\n", FILE_APPEND);
    }
}

function stopOpenVpnServer($ovpnctl) {
    exec('sudo -n ' . escapeshellarg($ovpnctl) . ' stop 2>&1');
    clearstatcache();
}

function getActiveServerSettings($serverConf) {
    $ip = $_SERVER['SERVER_ADDR'] ?? gethostbyname(gethostname()) ?? '127.0.0.1';
    $port = '1194';
    $hostIp = '10.8.0.1';
    $netMask = '255.255.255.0';

    if (file_exists($serverConf)) {
        $content = (string)@file_get_contents($serverConf);
        if (preg_match('/^port (\d+)/m', $content, $mPort)) {
            $port = trim($mPort[1]);
        }
        if (preg_match('/^# client-remote-host (.+)/m', $content, $mIp)) {
            $ip = trim($mIp[1]);
        }
        if (preg_match('/^# vpn-host-ip (.+)/m', $content, $mHost)) {
            $hostIp = trim($mHost[1]);
        } elseif (preg_match('/^server\s+([0-9\.]+)\s+([0-9\.]+)/m', $content, $mNet)) {
            $parsedNet = trim($mNet[1]);
            $longNet = ip2long($parsedNet);
            if ($longNet !== false) {
                $hostIp = long2ip($longNet + 1);
            }
        }
        if (preg_match('/^server\s+([0-9\.]+)\s+([0-9\.]+)/m', $content, $mNet)) {
            $netMask = trim($mNet[2]);
        }
    }
    return ['ip' => $ip, 'port' => $port, 'host_ip' => $hostIp, 'net_mask' => $netMask];
}

// ============================================================================
// Read-only AJAX endpoints (no state change -> no CSRF token required)
// ============================================================================
if (isset($_GET['action']) && $_GET['action'] === 'fetch_log') {
    if (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: text/plain; charset=utf-8');
    if (file_exists($logFile)) {
        $lines = explode("\n", tailFile($logFile, 200));
        $cleanLines = [];
        foreach ($lines as $line) {
            if (strpos($line, 'global-message-banner') === false && strpos($line, 'Unsigned Module') === false) {
                $cleanLines[] = strip_tags($line);
            }
        }
        echo trim(implode("\n", $cleanLines));
    } else {
        echo 'No log output available.';
    }
    exit();
}

if (isset($_GET['action']) && $_GET['action'] === 'fetch_public_ip') {
    if (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: text/plain; charset=utf-8');
    $publicIp = @file_get_contents('https://api.ipify.org');
    echo $publicIp ? trim($publicIp) : ($_SERVER['SERVER_ADDR'] ?? '');
    exit();
}

// ============================================================================
// Write AJAX endpoint (state change -> CSRF token required)
// ============================================================================
if (isset($_POST['action']) && $_POST['action'] === 'add_page_break') {
    csrf_require();
    if (ob_get_level()) { ob_end_clean(); }
    if (file_exists($logFile)) {
        $dividerText = "\n#############################################\n--- SEPARATOR (" . date('Y-m-d H:i:s') . ") ---\n#############################################\n";
        $written = @file_put_contents($logFile, $dividerText, FILE_APPEND);
        echo $written !== false ? 'success' : 'error_write';
    } else {
        echo 'error_nofile';
    }
    exit();
}

require_once __DIR__ . '/ovpn_mgr.class.php';
$freepbxObj = \FreePBX::create();
$ovpn_mgr = new \FreePBX\modules\Ovpn_mgr($freepbxObj);

// ============================================================================
// Sign Module (no root involved - only re-hashes files this module already
// owns. The old password field here was never even used by the handler;
// it has been removed.)
// ============================================================================
if (isset($_POST['action']) && $_POST['action'] === 'resign_custom_module_with_pass') {
    csrf_require();
    if (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: application/json');

    $modulePath = $moduleRoot;
    $signerScript = file_exists("{$modulePath}/devtools/signer.php")
        ? "{$modulePath}/devtools/signer.php"
        : "{$modulePath}/signer.php";

    if (file_exists($signerScript)) {
        $cmd = sprintf('/usr/bin/php %s %s 2>&1', escapeshellarg($signerScript), escapeshellarg($modulePath));
        exec($cmd, $output, $returnVar);
        clearstatcache(true, "{$modulePath}/module.sig");

        if (file_exists("{$modulePath}/module.sig")) {
            if (isset($pdo)) {
                try {
                    $pdo->exec("DELETE FROM notifications WHERE module IN ('core', 'framework', 'freepbx')");
                } catch (\Exception $e) {}
            }
            echo json_encode(['status' => 'success']);
            exit();
        }
        echo json_encode(['status' => 'error', 'message' => implode("\n", $output)]);
        exit();
    }
    echo json_encode(['status' => 'error', 'message' => 'Signer script not found.']);
    exit();
}

// ============================================================================
// Service Control
// ============================================================================
if (isset($_POST['action']) && $_POST['action'] === 'manage_service') {
    csrf_require();
    $serviceAction = $_POST['service_cmd'] ?? '';
    $settingsNow = getActiveServerSettings($serverConf);

    if ($serviceAction === 'start' || $serviceAction === 'restart') {
        @unlink("{$baseDir}/.stopped");
        stopOpenVpnServer($ovpnctl);
        sleep(1);
        startOpenVpnServer($ovpnctl, $serverConf, $baseDir, $serverKey);
    } elseif ($serviceAction === 'stop') {
        @touch("{$baseDir}/.stopped");
        stopOpenVpnServer($ovpnctl);
    }
    header("Location: config.php?display=ovpn_mgr");
    exit();
}

// Check for Sign Module Button Visibility
$show_ovpn_resign_button = false;
if (class_exists('FreePBX')) {
    $notifications = \FreePBX::Notifications();
    if (
        $notifications->exists('core', 'SIGNATURE_NOT_VALID') ||
        $notifications->exists('framework', 'TAMPERED_FILES') ||
        (function_exists('posix_getpwuid') && !file_exists("{$moduleRoot}/module.sig"))
    ) {
        $show_ovpn_resign_button = true;
    }
}

// ============================================================================
// Save Server Settings
// ============================================================================
$settingsError = '';
if (isset($_POST['action']) && $_POST['action'] === 'update_server_settings') {
    csrf_require();

    $newPort   = intval($_POST['ovpn_port']);
    $newIp     = trim((string)($_POST['server_ip'] ?? ''));
    $newHostIp = trim((string)($_POST['ovpn_host_ip'] ?? ''));
    $newCidr   = intval($_POST['ovpn_cidr'] ?? 24);

    if ($newPort <= 0 || $newPort >= 65535) {
        $settingsError = 'Invalid port.';
    } elseif (!isValidHostOrIp($newIp)) {
        $settingsError = 'Server Public IP / Host must be a plain IP address or hostname.';
    } elseif (!filter_var($newHostIp, FILTER_VALIDATE_IP)) {
        $settingsError = 'VPN Host IP must be a valid IP address.';
    } else {
        $oldSettings = getActiveServerSettings($serverConf);
        $oldPort     = intval($oldSettings['port']);
        $oldIp       = $oldSettings['ip'];

        $newNetmask    = cidrToNetmask($newCidr);
        $subnetDetails = calculateSubnetDetails($newHostIp, $newNetmask);
        $newNetIp      = $subnetDetails['net_ip'];

        // OpenVPN's "server" directive always assigns itself the first
        // usable address of the subnet (network + 1) - it is not
        // actually configurable to anything else. Rather than silently
        // accept a value the daemon will never really use, always
        // correct to that address and tell the admin why, whether their
        // input was the network/broadcast address or just some other
        // host in the block.
        $finalHostIp = $subnetDetails['suggested_first'];
        $hostIpWasCorrected = ($finalHostIp !== $newHostIp);

        // Stop the currently-running daemon BEFORE rewriting the config.
        // ovpnctl matches the process by the config file's live content,
        // so doing this after the rewrite (the previous order) meant it
        // was hunting for a process using the *new* port/settings that
        // didn't exist yet, leaving the real old process (and its tun
        // interface) running untouched until a manual restart.
        $wasStopped = file_exists("{$baseDir}/.stopped");
        if (!$wasStopped) {
            stopOpenVpnServer($ovpnctl);
            sleep(1);
        }

        $confContent = (string)@file_get_contents($serverConf);
        $confContent = preg_replace('/^port \d+/m', "port {$newPort}", $confContent);

        if (preg_match('/^server\s+[0-9\.]+\s+[0-9\.]+/m', $confContent)) {
            $confContent = preg_replace('/^server\s+[0-9\.]+\s+[0-9\.]+/m', "server {$newNetIp} {$newNetmask}", $confContent);
        } else {
            $confContent .= "\nserver {$newNetIp} {$newNetmask}";
        }

        // newIp/finalHostIp have already been through isValidHostOrIp() /
        // FILTER_VALIDATE_IP above, so they cannot contain newlines or
        // other characters that could inject additional config directives.
        if (preg_match('/^# vpn-host-ip .*/m', $confContent)) {
            $confContent = preg_replace('/^# vpn-host-ip .*/m', "# vpn-host-ip {$finalHostIp}", $confContent);
        } else {
            $confContent .= "\n# vpn-host-ip {$finalHostIp}";
        }
        if (preg_match('/^# client-remote-host .*/m', $confContent)) {
            $confContent = preg_replace('/^# client-remote-host .*/m', "# client-remote-host {$newIp}", $confContent);
        } else {
            $confContent .= "\n# client-remote-host {$newIp}";
        }
        @file_put_contents($serverConf, $confContent);

        exec("ip route show default | awk '{print \$5}'", $defaultIfOut);
        $primaryIf = '';
        foreach ($defaultIfOut as $ifLine) {
            $ifLine = trim($ifLine);
            if ($ifLine !== '' && preg_match('/^[a-zA-Z0-9_.@-]{1,15}$/', $ifLine)) {
                $primaryIf = $ifLine;
                break;
            }
        }
        if ($primaryIf === '') { $primaryIf = 'ens192'; }

        // Open the new port via the same file FreePBX's own "Advanced
        // Settings > Custom Firewall Rules" GUI reads/writes (see
        // syncOvpnFirewallPortRule() above for why this replaced the old
        // "fwconsole firewall add/del external <port>" calls - those never
        // actually opened anything).
        $fwSyncResult = syncOvpnFirewallPortRule($newPort, $logFile, $ovpnctl);
        if (!$fwSyncResult['written'] || !$fwSyncResult['reloaded']) {
            $_SESSION['ovpn_mgr_fw_warning'] = $fwSyncResult['message'];
        }

        applyVpnRoutingAndNat($ovpnctl, $newNetIp, $subnetDetails['cidr'], $primaryIf);

        if (!$wasStopped) {
            startOpenVpnServer($ovpnctl, $serverConf, $baseDir, $serverKey);
        }

        // Flash notice for the next page load: host-ip correction, and/or
        // an offer to revoke+rebuild existing packages if the address or
        // port clients connect to actually changed.
        $existingPkgCount = count(glob("{$pkgDir}/*.tar"));
        $addressChanged = ($oldIp !== $newIp) || ($oldPort !== $newPort);
        if ($hostIpWasCorrected || ($addressChanged && $existingPkgCount > 0)) {
            $_SESSION['ovpn_mgr_flash'] = [
                'host_ip_corrected' => $hostIpWasCorrected,
                'entered_host_ip'   => $newHostIp,
                'final_host_ip'     => $finalHostIp,
                'address_changed'   => $addressChanged,
                'pkg_count'         => $existingPkgCount,
            ];
        }

        header("Location: config.php?display=ovpn_mgr");
        exit();
    }
}

// ============================================================================
// Client package builder - shared by "Generate Package" and "Revoke &
// Rebuild All" below. Only ever touches asterisk-owned files under
// pkiDir/baseDir/pkgDir, so this needs no elevated privilege.
// ============================================================================
function buildClientPackage($pkiDir, $pkgDir, $baseDir, $ext, $mac, $serverIp, $port) {
    if (!file_exists($pkgDir)) {
        @mkdir($pkgDir, 0775, true);
    }

    $clientKey = "{$pkiDir}/private/{$ext}.key";
    $clientCrt = "{$pkiDir}/issued/{$ext}.crt";
    $clientCsr = "{$pkiDir}/{$ext}.csr";

    if (!file_exists($clientCrt)) {
        exec("openssl req -new -nodes -batch -sha1 -newkey rsa:1024 -out " . escapeshellarg($clientCsr) . " -keyout " . escapeshellarg($clientKey) . " -subj " . escapeshellarg("/CN={$ext}/") . " 2>&1");
        exec("openssl x509 -req -days 3650 -sha1 -in " . escapeshellarg($clientCsr) . " -CA " . escapeshellarg("{$pkiDir}/ca.crt") . " -CAkey " . escapeshellarg("{$pkiDir}/private/ca.key") . " -set_serial " . random_int(100, 99999) . " -out " . escapeshellarg($clientCrt) . " 2>&1");
        @unlink($clientCsr);
    }

    $buildDir = "{$baseDir}/build_{$ext}";
    $keysSubDir = "{$buildDir}/keys";
    @mkdir($keysSubDir, 0775, true);

    @copy("{$pkiDir}/ca.crt", "{$keysSubDir}/ca.crt");
    @copy($clientCrt, "{$keysSubDir}/client.crt");
    @copy($clientKey, "{$keysSubDir}/client.key");

    $vpnCnf = "client\n"
            . "nobind\n"
            . "remote {$serverIp} {$port}\n"
            . "proto udp\n"
            . "dev tun\n"
            . "ca /config/openvpn/keys/ca.crt\n"
            . "cert /config/openvpn/keys/client.crt\n"
            . "key /config/openvpn/keys/client.key\n"
            . "cipher AES-128-CBC\n"
            . "auth SHA1\n"
            . "verb 3\n"
            . "explicit-exit-notify 0\n"
            . "script-security 2\n";
    @file_put_contents("{$buildDir}/vpn.cnf", $vpnCnf);

    // This module only builds the VPN transport package - it deliberately
    // does not generate any SIP/account provisioning config (that's a
    // separate concern for whatever endpoint-manager module you use).
    $members = [];
    foreach (['keys', 'vpn.cnf'] as $member) {
        if (file_exists("{$buildDir}/{$member}")) {
            $members[] = $member;
        }
    }

    // A random suffix keeps package filenames from being guessable by
    // MAC/extension alone, since these packages are served as plain
    // static files to unauthenticated phones and can't require a login.
    $pkgToken = bin2hex(random_bytes(4));
    $tarPath = "{$pkgDir}/{$mac}_{$ext}_{$pkgToken}_ovpn.tar";

    $tarCmd = "tar -cf " . escapeshellarg($tarPath) . " -C " . escapeshellarg($buildDir);
    foreach ($members as $member) {
        $tarCmd .= ' ' . escapeshellarg($member);
    }
    exec($tarCmd . ' 2>&1', $tarOut, $tarRc);

    $ok = ($tarRc === 0 && file_exists($tarPath));
    if ($ok) {
        @chmod($tarPath, 0644);
    } else {
        @unlink($tarPath);
    }

    exec("rm -rf " . escapeshellarg($buildDir));
    return $ok ? $tarPath : null;
}

if (isset($_POST['action']) && $_POST['action'] === 'generate_package') {
    csrf_require();

    $ext = preg_replace('/[^0-9]/', '', (string)($_POST['ext'] ?? ''));
    $mac = strtolower(preg_replace('/[^a-fA-F0-9]/', '', (string)($_POST['mac'] ?? '')));

    if (!empty($ext) && !empty($mac)) {
        $settings = getActiveServerSettings($serverConf);
        buildClientPackage($pkiDir, $pkgDir, $baseDir, $ext, $mac, $settings['ip'], $settings['port']);
    }
    header("Location: config.php?display=ovpn_mgr");
    exit();
}

// Revoke every existing client's cert and rebuild its package against the
// server's current address/port. Offered to the admin after a settings
// save that changed the address/port existing packages were built for.
if (isset($_POST['action']) && $_POST['action'] === 'rebuild_all_packages') {
    csrf_require();

    $settings = getActiveServerSettings($serverConf);
    $existingPkgs = glob("{$pkgDir}/*.tar");
    $rebuilt = 0;

    foreach ($existingPkgs as $pkgPath) {
        $filename = basename($pkgPath);
        $mac = '';
        $ext = '';
        if (preg_match('/^([a-f0-9]+)_(\d+)_[a-f0-9]{8}_ovpn\.tar$/i', $filename, $m)) {
            $mac = strtolower($m[1]);
            $ext = $m[2];
        } elseif (preg_match('/^([a-f0-9]+)_(\d+)_ovpn\.tar$/i', $filename, $m)) {
            $mac = strtolower($m[1]);
            $ext = $m[2];
        }
        if ($ext === '' || $mac === '') {
            continue; // can't determine which extension this belonged to - leave it alone
        }

        revokeExtension($pkiDir, $serverConf, $crlFile, $pkgDir, $ext);
        @unlink($pkgPath);
        if (buildClientPackage($pkiDir, $pkgDir, $baseDir, $ext, $mac, $settings['ip'], $settings['port'])) {
            $rebuilt++;
        }
    }

    if (!file_exists("{$baseDir}/.stopped")) {
        stopOpenVpnServer($ovpnctl);
        sleep(1);
        startOpenVpnServer($ovpnctl, $serverConf, $baseDir, $serverKey);
    }

    unset($_SESSION['ovpn_mgr_flash']);
    header("Location: config.php?display=ovpn_mgr");
    exit();
}

// ============================================================================
// Certificate revocation helper (shared by the two actions below)
// ============================================================================
function revokeExtension($pkiDir, $serverConf, $crlFile, $pkgDir, $revokeExt) {
    $targetCrt = "{$pkiDir}/issued/{$revokeExt}.crt";
    $targetKey = "{$pkiDir}/private/{$revokeExt}.key";

    if (!file_exists($targetCrt)) {
        return;
    }

    $tmpCnf = "{$pkiDir}/crl_openssl.cnf";
    $cnfData = "[ ca ]\ndefault_ca = CA_default\n\n[ CA_default ]\ndir = {$pkiDir}\ndefault_md = sha256\n";
    @file_put_contents($tmpCnf, $cnfData);

    if (!file_exists("{$pkiDir}/index.txt")) { @touch("{$pkiDir}/index.txt"); }
    if (!file_exists("{$pkiDir}/crlnumber")) { @file_put_contents("{$pkiDir}/crlnumber", "01\n"); }

    exec("OPENSSL_CONF=" . escapeshellarg($tmpCnf) . " openssl ca -revoke " . escapeshellarg($targetCrt) . " -keyfile " . escapeshellarg("{$pkiDir}/private/ca.key") . " -cert " . escapeshellarg("{$pkiDir}/ca.crt") . " -config " . escapeshellarg($tmpCnf) . " 2>&1");
    exec("OPENSSL_CONF=" . escapeshellarg($tmpCnf) . " openssl ca -gencrl -keyfile " . escapeshellarg("{$pkiDir}/private/ca.key") . " -cert " . escapeshellarg("{$pkiDir}/ca.crt") . " -out " . escapeshellarg($crlFile) . " -config " . escapeshellarg($tmpCnf) . " 2>&1");
    @unlink($tmpCnf);

    $confContent = (string)@file_get_contents($serverConf);
    if (strpos($confContent, 'crl-verify') === false) {
        $confContent .= "\ncrl-verify {$crlFile}\n";
        @file_put_contents($serverConf, $confContent);
    }

    @unlink($targetCrt);
    @unlink($targetKey);

    foreach (glob("{$pkgDir}/*_{$revokeExt}_*_ovpn.tar") as $matchingTar) { @unlink($matchingTar); }
    foreach (glob("{$pkgDir}/*_{$revokeExt}_ovpn.tar") as $matchingTar) { @unlink($matchingTar); } // legacy naming
}

// Handle Certificate Revocation (now POST-only - GET requests must never
// change state, or any link/image tag anywhere could trigger this via CSRF)
if (isset($_POST['action']) && $_POST['action'] === 'revoke_cert') {
    csrf_require();
    $revokeExt = preg_replace('/[^0-9]/', '', (string)($_POST['revoke_ext'] ?? ''));
    if (!empty($revokeExt)) {
        revokeExtension($pkiDir, $serverConf, $crlFile, $pkgDir, $revokeExt);
        if (!file_exists("{$baseDir}/.stopped")) {
            stopOpenVpnServer($ovpnctl);
            sleep(1);
            startOpenVpnServer($ovpnctl, $serverConf, $baseDir, $serverKey);
        }
    }
    header("Location: config.php?display=ovpn_mgr");
    exit();
}

// Handle Package Deletion (also POST-only now)
if (isset($_POST['action']) && $_POST['action'] === 'delete_package') {
    csrf_require();
    $targetPkg = basename((string)($_POST['pkg'] ?? ''));
    $fullPath = "{$pkgDir}/{$targetPkg}";

    $looksLikeOurPkg = (strpos($targetPkg, '_ovpn.tar') !== false) || (strpos($targetPkg, '_keys.tar') !== false)
        || (strpos($targetPkg, '-keys.tar') !== false) || (strpos($targetPkg, 'keys_') === 0);

    if (file_exists($fullPath) && $looksLikeOurPkg) {
        $revokeExt = '';
        if (preg_match('/^[a-f0-9]+_(\d+)_[a-f0-9]{8}_ovpn\.tar$/i', $targetPkg, $m)) {
            $revokeExt = $m[1]; // current naming: mac_ext_token_ovpn.tar
        } elseif (preg_match('/^[a-f0-9]+_(\d+)_(ovpn|keys)\.tar$/i', $targetPkg, $m)) {
            $revokeExt = $m[1]; // legacy naming
        } elseif (preg_match('/^keys_(\d+)_/i', $targetPkg, $m) || preg_match('/^(\d+)-/i', $targetPkg, $m)) {
            $revokeExt = $m[1];
        }

        @unlink($fullPath);

        if (!empty($revokeExt)) {
            revokeExtension($pkiDir, $serverConf, $crlFile, $pkgDir, $revokeExt);
            if (!file_exists("{$baseDir}/.stopped")) {
                stopOpenVpnServer($ovpnctl);
                sleep(1);
                startOpenVpnServer($ovpnctl, $serverConf, $baseDir, $serverKey);
            }
        }
    }
    header("Location: config.php?display=ovpn_mgr");
    exit();
}

// ============================================================================
// Bulk actions for the "Created Provisioning Archives" table (checkbox
// selection). Both share the same validation as the single-item
// delete_package handler above: basename() only, and the filename must
// look like one of our own package names before it's ever touched.
// ============================================================================
function ovpnValidateSelectedPkg($pkgDir, $name) {
    $name = basename((string)$name);
    $looksLikeOurPkg = (strpos($name, '_ovpn.tar') !== false) || (strpos($name, '_keys.tar') !== false)
        || (strpos($name, '-keys.tar') !== false) || (strpos($name, 'keys_') === 0);
    $full = "{$pkgDir}/{$name}";
    return ($looksLikeOurPkg && file_exists($full)) ? $name : null;
}

if (isset($_POST['action']) && $_POST['action'] === 'bulk_download_packages') {
    csrf_require();
    $selected = (array)($_POST['pkgs'] ?? []);
    $validFiles = [];
    foreach ($selected as $name) {
        $valid = ovpnValidateSelectedPkg($pkgDir, $name);
        if ($valid !== null) { $validFiles[] = $valid; }
    }
    if (empty($validFiles)) {
        header("Location: config.php?display=ovpn_mgr");
        exit();
    }
    // Discard any output buffer(s) FreePBX's own page framework may have
    // already started before this module's action code ran - e.g. nav
    // chrome, or (very plausible on a heavily-hand-edited module like
    // this one) the "module signature invalid / tampered files" warning
    // banner. If even one byte of that HTML leaks out ahead of the tar
    // header, the result is a corrupted archive: most tar readers,
    // including 7-Zip, require the tar header at byte 0 and simply
    // refuse to open anything else. This has to happen *before* the
    // header() calls below, and in a loop since the framework may have
    // nested buffers.
    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    // Bundle the selected .tar packages into one outer .tar so the browser
    // gets a single "Save As" dialog instead of N simultaneous downloads.
    $bundleName = 'ovpn_packages_' . date('Ymd_His') . '.tar';
    $args = array_map('escapeshellarg', $validFiles);
    header('Content-Description: File Transfer');
    header('Content-Type: application/x-tar');
    header('Content-Disposition: attachment; filename="' . $bundleName . '"');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');
    flush();
    passthru('cd ' . escapeshellarg($pkgDir) . ' && tar -cf - ' . implode(' ', $args));
    exit();
}

if (isset($_POST['action']) && $_POST['action'] === 'bulk_revoke_packages') {
    csrf_require();
    $selected = (array)($_POST['pkgs'] ?? []);
    $revokedCount = 0;

    foreach ($selected as $name) {
        $valid = ovpnValidateSelectedPkg($pkgDir, $name);
        if ($valid === null) { continue; }

        $revokeExt = '';
        if (preg_match('/^[a-f0-9]+_(\d+)_[a-f0-9]{8}_ovpn\.tar$/i', $valid, $m)) {
            $revokeExt = $m[1];
        } elseif (preg_match('/^[a-f0-9]+_(\d+)_(ovpn|keys)\.tar$/i', $valid, $m)) {
            $revokeExt = $m[1];
        } elseif (preg_match('/^keys_(\d+)_/i', $valid, $m) || preg_match('/^(\d+)-/i', $valid, $m)) {
            $revokeExt = $m[1];
        }

        @unlink("{$pkgDir}/{$valid}");

        if (!empty($revokeExt)) {
            revokeExtension($pkiDir, $serverConf, $crlFile, $pkgDir, $revokeExt);
            $revokedCount++;
        }
    }

    // One restart at the end (like Revoke & Rebuild All) instead of once
    // per selected item - the CRL only needs to be picked up once.
    if ($revokedCount > 0 && !file_exists("{$baseDir}/.stopped")) {
        stopOpenVpnServer($ovpnctl);
        sleep(1);
        startOpenVpnServer($ovpnctl, $serverConf, $baseDir, $serverKey);
    }

    header("Location: config.php?display=ovpn_mgr");
    exit();
}

// Same idea as "Rebuild All" above, but scoped to just the checked rows -
// revokes each selected package's cert and immediately issues a fresh one
// against the server's current address/port, instead of only deleting.
if (isset($_POST['action']) && $_POST['action'] === 'bulk_revoke_rebuild_packages') {
    csrf_require();
    $selected = (array)($_POST['pkgs'] ?? []);
    $settings = getActiveServerSettings($serverConf);
    $rebuilt = 0;

    foreach ($selected as $name) {
        $valid = ovpnValidateSelectedPkg($pkgDir, $name);
        if ($valid === null) { continue; }

        $mac = '';
        $ext = '';
        if (preg_match('/^([a-f0-9]+)_(\d+)_[a-f0-9]{8}_ovpn\.tar$/i', $valid, $m)) {
            $mac = strtolower($m[1]);
            $ext = $m[2];
        } elseif (preg_match('/^([a-f0-9]+)_(\d+)_ovpn\.tar$/i', $valid, $m)) {
            $mac = strtolower($m[1]);
            $ext = $m[2];
        }
        if ($ext === '' || $mac === '') {
            continue; // can't determine mac/ext from this filename - leave it alone
        }

        revokeExtension($pkiDir, $serverConf, $crlFile, $pkgDir, $ext);
        @unlink("{$pkgDir}/{$valid}");
        if (buildClientPackage($pkiDir, $pkgDir, $baseDir, $ext, $mac, $settings['ip'], $settings['port'])) {
            $rebuilt++;
        }
    }

    if ($rebuilt > 0 && !file_exists("{$baseDir}/.stopped")) {
        stopOpenVpnServer($ovpnctl);
        sleep(1);
        startOpenVpnServer($ovpnctl, $serverConf, $baseDir, $serverKey);
    }

    header("Location: config.php?display=ovpn_mgr");
    exit();
}

clearstatcache();

$activeSettings = getActiveServerSettings($serverConf);
$currentPort = $activeSettings['port'];
$currentServerIp = $activeSettings['ip'];
$currentHostIp = $activeSettings['host_ip'];
$currentNetMask = $activeSettings['net_mask'];

$subnetDetails = calculateSubnetDetails($currentHostIp, $currentNetMask);
$currentCidr = $subnetDetails['cidr'];
// Usable client IPs for this CIDR block: total host addresses minus
// network + broadcast, minus 1 more for the address OpenVPN's "server"
// directive always reserves for itself.
$currentClientIpCount = max(0, (pow(2, 32 - $currentCidr) - 2) - 1);

// Safe log reader - the file is owned by us, no sudo needed.
$logContent = tailFile($logFile, 200);
$hasTunError = (strpos($logContent, 'Cannot ioctl TUNSETIFF') !== false || strpos($logContent, 'Exiting due to fatal error') !== false);

// Process check
$pids = [];
if (!file_exists("{$baseDir}/.stopped")) {
    if (file_exists($pidFile)) {
        $savedPid = intval(trim((string)@file_get_contents($pidFile)));
        if ($savedPid > 0 && file_exists("/proc/{$savedPid}")) {
            $pids[] = $savedPid;
        } else {
            @unlink($pidFile);
        }
    }
    if (empty($pids)) {
        exec("pgrep -f 'legacy-vpn'", $rawPids);
        foreach ($rawPids as $rawPid) {
            $cleanPid = intval(trim($rawPid));
            if ($cleanPid > 0) {
                $pids[] = $cleanPid;
            }
        }
    }
}

$isRunning = !empty($pids) && !$hasTunError;
$ip_forward_active = (trim((string)@shell_exec('sysctl -n net.ipv4.ip_forward 2>/dev/null')) === '1');
$hasSudoRule = hasOvpnctlAccess($ovpnctl);

$createdPackages = glob("{$pkgDir}/*.tar");
$issuedCertFiles = glob("{$pkiDir}/issued/*.crt");

// Active Client & Cipher Parser
$connectedClients = [];
if (file_exists($logFile)) {
    $logData = (string)@file_get_contents($logFile);
    if (preg_match_all('/([A-Za-z0-9_\-]+)\/([\d\.]+:\d+)\s+MULTI_sva:\s+pool returned IPv4=([\d\.]+)/i', $logData, $matches, PREG_SET_ORDER)) {
        $seenIps = [];
        foreach (array_reverse($matches) as $m) {
            $clientName = $m[1];
            $realIp     = $m[2];
            $virtIp     = $m[3];
            if (!in_array($virtIp, $seenIps)) {
                $seenIps[] = $virtIp;
                $activeCipher = 'AES-128-CBC';
                if (preg_match_all('/Data Channel.*[C|c]ipher [\'"]?([A-Za-z0-9\-]+)[\'"]?/i', $logData, $cipherMatches)) {
                    $activeCipher = end($cipherMatches[1]);
                }
                $connectedClients[] = [
                    'mac'           => $clientName,
                    'virtual_ip'    => $virtIp,
                    'real_ip'       => $realIp,
                    'active_cipher' => $activeCipher,
                ];
            }
        }
    }
}
?>

<div class="container-fluid">
    <h1>OpenVPN Manager</h1>

    <?php if (!empty($settingsError)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($settingsError); ?></div>
    <?php endif; ?>

    <!-- Status Banner -->
    <div class="alert alert-<?php echo ($isRunning && $ip_forward_active) ? 'success' : 'danger'; ?>" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 15px; padding: 12px 18px;">
        <div style="display: flex; align-items: center; gap: 20px;">
            <div style="font-weight: bold; color: #333; font-size: 13px;">
                <span title="Checked by looking for a running process whose command line matches this module's OpenVPN config path.">OpenVPN Server Status:</span>
                <?php if ($isRunning): ?>
                    <span class="label label-success" style="font-size: 11px; padding: 4px 8px;" title="PID: <?php echo htmlspecialchars(implode(', ', $pids)); ?>">RUNNING</span>
                <?php else: ?>
                    <span class="label label-danger" style="font-size: 11px; padding: 4px 8px;" title="Service Stopped">STOPPED</span>
                <?php endif; ?>
            </div>
            <div style="font-weight: bold; color: #333; font-size: 13px;">
                <span title="Checked by running: sysctl -n net.ipv4.ip_forward (1 = active, 0 = inactive)">Kernel IP Forwarding:</span>
                <?php if ($ip_forward_active): ?>
                    <span class="label label-success" style="font-size: 11px; padding: 4px 8px;" title="net.ipv4.ip_forward = 1">ACTIVE</span>
                <?php else: ?>
                    <span class="label label-danger" style="font-size: 11px; padding: 4px 8px;" title="net.ipv4.ip_forward = 0">INACTIVE</span>
                <?php endif; ?>
            </div>
        </div>

        <div style="display: flex; align-items: center; gap: 8px;">
            <form method="post" action="config.php?display=ovpn_mgr" id="ovpnServiceForm" style="display: inline-block; margin: 0;">
                <input type="hidden" name="action" value="manage_service">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                <?php if ($isRunning): ?>
                    <button type="submit" name="service_cmd" value="stop" class="btn btn-danger btn-sm" style="background-color: #db001a; border-color: #6b000d;" data-confirm-message="Stop OpenVPN service? Remote clients will disconnect." <?php echo !$hasSudoRule ? 'disabled title="This module cannot manage this process yet - see the setup notice below"' : ''; ?>>
                        <i class="fa fa-stop"></i> Stop
                    </button>
                    <button type="submit" name="service_cmd" value="restart" class="btn btn-warning btn-sm" <?php echo !$hasSudoRule ? 'disabled title="This module cannot manage this process yet - see the setup notice below"' : ''; ?>>
                        <i class="fa fa-refresh"></i> Restart
                    </button>
                <?php else: ?>
                    <button type="submit" name="service_cmd" value="start" class="btn btn-success btn-sm" <?php echo !$hasSudoRule ? 'disabled title="Run the one-time root setup below first"' : ''; ?>>
                        <i class="fa fa-play"></i> Start
                    </button>
                <?php endif; ?>
            </form>
            <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#logModal">
                <i class="fa fa-file-text-o"></i> View Live Logs
            </button>
            <?php if ($show_ovpn_resign_button): ?>
                <button type="button" class="btn btn-danger btn-sm" style="margin: 0; font-weight: bold; background-color: #db001a; border-color: #6b000d;" data-toggle="modal" data-target="#signModal">
                    <i class="fa fa-key"></i> Sign Module
                </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- One-time root setup notice - replaces the old in-browser root
         password prompt. No password ever flows through this page. -->
    <?php if (!$hasSudoRule): ?>
        <div class="panel panel-warning" style="margin-bottom: 20px;">
            <div class="panel-heading"><h3 class="panel-title"><i class="fa fa-lock"></i> One-Time Root Setup Required</h3></div>
            <div class="panel-body">
                <p>This module needs a narrow, one-time root authorization before it can start the OpenVPN daemon, manage firewall rules, or enable IP forwarding. This is done once from an SSH/console session as root - never through this web page - so no root password is ever typed into or transmitted by the browser:</p>
                <pre id="setupCmd" title="Click to copy" style="background:#f8f9fa; padding:10px; border:1px solid #ccc; font-size:12px; cursor:pointer;" onclick="copySetupCommand()">sudo bash <?php echo htmlspecialchars($setupScript); ?></pre>
                <p style="margin-bottom: 0;">That script grants the web server user passwordless <code>sudo</code> on exactly one fixed helper script (<code>scripts/ovpnctl</code>) - nothing else, and restarts the daemon at the end so it comes up with a working <code>tun</code> interface immediately, without a separate manual restart. After running it, reload this page.</p>
            </div>
        </div>
    <?php elseif (!$ip_forward_active): ?>
        <div class="alert alert-warning" style="margin-bottom: 20px;">
            <i class="fa fa-exclamation-triangle"></i> IP forwarding is currently inactive. Starting the service will enable it.
        </div>
    <?php endif; ?>

    <?php
    $ovpnFwWarning = $_SESSION['ovpn_mgr_fw_warning'] ?? null;
    unset($_SESSION['ovpn_mgr_fw_warning']);
    ?>
    <?php if ($ovpnFwWarning): ?>
        <div class="alert alert-warning" style="margin-bottom: 20px;">
            <i class="fa fa-exclamation-triangle"></i> <strong>Firewall port may not be open yet:</strong> <?php echo nl2br(htmlspecialchars($ovpnFwWarning)); ?>
        </div>
    <?php endif; ?>

    <?php
    $ovpnFlash = $_SESSION['ovpn_mgr_flash'] ?? null;
    unset($_SESSION['ovpn_mgr_flash']);
    ?>
    <?php if ($ovpnFlash): ?>
        <div class="alert alert-info" style="margin-bottom: 20px;">
            <?php if (!empty($ovpnFlash['host_ip_corrected'])): ?>
                <p style="margin-bottom: <?php echo !empty($ovpnFlash['address_changed']) ? '10px' : '0'; ?>;">
                    <i class="fa fa-info-circle"></i>
                    VPN Host IP adjusted from <code><?php echo htmlspecialchars($ovpnFlash['entered_host_ip']); ?></code> to <code><?php echo htmlspecialchars($ovpnFlash['final_host_ip']); ?></code>.
                    OpenVPN's <code>server</code> directive always assigns itself the first usable address of the subnet - the value you entered was only used to pick which block to use.
                </p>
            <?php endif; ?>
            <?php if (!empty($ovpnFlash['address_changed']) && $ovpnFlash['pkg_count'] > 0): ?>
                <p style="margin-bottom: 10px;">
                    <i class="fa fa-exclamation-triangle"></i>
                    The server address/port changed. <?php echo intval($ovpnFlash['pkg_count']); ?> existing client package(s) still point at the old address and will stop connecting until rebuilt.
                </p>
                <form method="post" action="config.php?display=ovpn_mgr" style="display:inline;">
                    <input type="hidden" name="action" value="rebuild_all_packages">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                    <button type="submit" class="btn btn-warning btn-sm" data-confirm-message="Revoke and rebuild ALL <?php echo intval($ovpnFlash['pkg_count']); ?> existing client package(s) with the new server address? Old packages will stop working immediately.">
                        <i class="fa fa-refresh"></i> Revoke & Rebuild All (<?php echo intval($ovpnFlash['pkg_count']); ?>)
                    </button>
                </form>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- Top Layout Grid: Server Settings & Connected Clients -->
    <div class="row">
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading"><h3 class="panel-title"><i class="fa fa-cogs"></i> OpenVPN Server Settings</h3></div>
                <div class="panel-body">
                    <form method="post" action="config.php?display=ovpn_mgr" id="ovpnSettingsForm">
                        <input type="hidden" name="action" value="update_server_settings">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">

                        <div style="display: flex; align-items: flex-end; gap: 5px; margin-bottom: 15px; flex-wrap: wrap;">
                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="server_ip" style="font-size: 11px; display: block; margin-bottom: 5px; padding-left: 5px;">Server Public IP / Host</label>
                                <input type="text" class="form-control" id="server_ip" name="server_ip" value="<?php echo htmlspecialchars($currentServerIp); ?>" required style="width: 135px; height: 34px;">
                            </div>
                            <div class="form-group" style="margin-bottom: 0;">
                                <label style="font-size: 11px; visibility: hidden; display: block; margin-bottom: 5px;">Action</label>
                                <button type="button" class="btn btn-default btn-sm" onclick="setPrivateIp()" style="width: 95px; height: 34px; padding: 4px 6px; font-size: 13px;" title="Auto-fill Local LAN IP">
                                    <i class="fa fa-sitemap"></i> Private IP
                                </button>
                            </div>
                            <div class="form-group" style="margin-bottom: 0;">
                                <label style="font-size: 11px; visibility: hidden; display: block; margin-bottom: 5px;">Action</label>
                                <button type="button" class="btn btn-default btn-sm" onclick="fetchPublicIp()" style="width: 95px; height: 34px; padding: 4px 6px; font-size: 13px;" title="Auto-fill WAN IP">
                                    <i class="fa fa-globe"></i> Public IP
                                </button>
                            </div>
                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="ovpn_port" style="font-size: 11px; display: block; margin-bottom: 5px; padding-left: 3px;">Port</label>
                                <input type="number" class="form-control" id="ovpn_port" name="ovpn_port" value="<?php echo htmlspecialchars($currentPort); ?>" required style="width: 75px; height: 34px; padding: 6px 4px;">
                            </div>
                        </div>

                        <div style="display: flex; align-items: flex-end; gap: 10px; margin-bottom: 6px; flex-wrap: wrap;">
                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="ovpn_host_ip" style="font-size: 11px; display: block; margin-bottom: 5px; padding-left: 3px;">VPN Host IP</label>
                                <input type="text" class="form-control" id="ovpn_host_ip" name="ovpn_host_ip" value="<?php echo htmlspecialchars($currentHostIp); ?>" required style="width: 130px; height: 34px;" oninput="recalculateRange()">
                            </div>
                            <div class="form-group" style="margin-bottom: 0;">
                                <label for="ovpn_cidr" style="font-size: 11px; display: block; margin-bottom: 5px; padding-left: 11px;">CIDR</label>
                                <div style="display: flex; align-items: center;">
                                    <span style="padding: 6px 4px 6px 0; font-size: 14px; color: #666;">/</span>
                                    <input type="number" class="form-control" id="ovpn_cidr" name="ovpn_cidr" value="<?php echo htmlspecialchars($currentCidr); ?>" min="16" max="29" required style="width: 65px; height: 34px; padding: 6px 4px; padding-left: 5px;" oninput="recalculateRange()">
                                </div>
                            </div>
                            <div class="form-group" style="margin-bottom: 0;">
                                <label style="font-size: 11px; display: block; margin-bottom: 5px; padding-left: 4px;">Calculated IP Range</label>
                                <div class="well well-sm" id="ip_range_box" style="margin-bottom: 0; padding: 6px 10px; height: 34px; font-size: 11px; font-family: monospace; font-weight: bold; background: #f8f9fa; border-color: #ccc; white-space: nowrap;">
                                    <span id="range_start"><?php echo htmlspecialchars($subnetDetails['range_start']); ?></span> - <span id="range_end"><?php echo htmlspecialchars($subnetDetails['range_end']); ?></span>
                                </div>
                            </div>
                            <div class="form-group" style="margin-bottom: 0;">
                                <label style="font-size: 11px; display: block; margin-bottom: 5px; padding-left: 3px;">Client IPs</label>
                                <div class="well well-sm" id="client_ip_count_box" style="margin-bottom: 0; padding: 6px 10px; height: 34px; font-size: 11px; font-family: monospace; font-weight: bold; background: #f8f9fa; border-color: #ccc; white-space: nowrap; text-align: center;" title="Usable client addresses in this block, after the network/broadcast addresses and the one address OpenVPN reserves for itself">
                                    <span id="client_ip_count"><?php echo (int)$currentClientIpCount; ?></span>
                                </div>
                            </div>
                        </div>

                        <div id="host_ip_live_notice" style="display: none; margin-bottom: 10px; font-size: 11px; padding: 6px 10px; border-radius: 4px;"></div>

                        <button type="submit" class="btn btn-primary btn-block" style="max-width: 420px;">
                            <i class="fa fa-save"></i> Save Settings & Restart Daemon
                        </button>
                    </form>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading" style="display: flex; align-items: center; padding: 10px 15px;"><h3 class="panel-title" style="margin: 0;"><i class="fa fa-cube"></i> Build Provisioning Package (vpn.tar)</h3></div>
                <div class="panel-body">
                    <form method="post" action="config.php?display=ovpn_mgr">
                        <input type="hidden" name="action" value="generate_package">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                        <div style="display: flex; align-items: flex-end; gap: 30px; margin-bottom: 10px; flex-wrap: wrap;">
                            <div class="form-group" style="margin-bottom: 0;">
                                <label style="font-size: 11px; display: block; margin-bottom: 5px; padding-left: 5px;">Extension</label>
                                <input type="text" name="ext" class="form-control" placeholder="101" required style="width: 130px; height: 34px;">
                            </div>
                            <div class="form-group" style="margin-bottom: 0;">
                                <label style="font-size: 11px; display: block; margin-bottom: 5px; padding-left: 5px;">Phone MAC Address</label>
                                <input type="text" name="mac" class="form-control" placeholder="00155D010203" required style="width: 190px; height: 34px;">
                            </div>
                        </div>
                        <div class="well well-sm" style="font-size: 11px; margin-bottom: 10px; padding: 5px; color: #555; max-width: 350px;">
                            Package will target OpenVPN <strong><?php echo htmlspecialchars($currentServerIp); ?>:<?php echo htmlspecialchars($currentPort); ?></strong> and SIP Gateway <strong><?php echo htmlspecialchars($currentHostIp); ?>:5060</strong>
                        </div>
                        <button type="submit" class="btn btn-success btn-block" style="max-width: 350px;">
                            <i class="fa fa-plus"></i> Generate Keys & Build Package
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading"><h3 class="panel-title"><i class="fa fa-users"></i> Connected OpenVPN Clients</h3></div>
                <!-- Grows to fit content up to ~20 rows (thead ~41px + 20 * ~42px), then scrolls. -->
                <div class="panel-body" style="padding: 0; max-height: 300px; overflow-y: auto;">
                    <table class="table table-striped table-bordered" style="margin-bottom: 0; font-size: 12px;">
                        <thead>
                            <tr><th>Extension / MAC</th><th>Virtual IP (TUN)</th><th>Real IP / Peer</th><th>Active Cipher</th></tr>
                        </thead>
                        <tbody>
                            <?php if (empty($connectedClients)): ?>
                                <tr><td colspan="4" class="text-muted" style="padding: 12px; text-align: center;">No active client tunnels currently connected.</td></tr>
                            <?php else: foreach ($connectedClients as $client): ?>
                                <tr>
                                    <td><code><?php echo htmlspecialchars($client['mac']); ?></code></td>
                                    <td><code><?php echo htmlspecialchars($client['virtual_ip']); ?></code></td>
                                    <td><?php echo htmlspecialchars($client['real_ip']); ?></td>
                                    <td><span class="label label-info"><?php echo htmlspecialchars($client['active_cipher']); ?></span></td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading" style="display: flex; align-items: center; justify-content: space-between; padding: 10px 15px;">
                    <h3 class="panel-title" style="margin: 0;"><i class="fa fa-archive"></i> Created Provisioning Archives</h3>
                    <button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target="#revokeModal">
                        <i class="fa fa-key"></i> Manage / Revoke Keys (<?php echo count($issuedCertFiles); ?>)
                    </button>
                </div>
                <!-- Grows to fit content up to ~20 rows (thead ~33px + 20 * ~35px), then scrolls. -->
                <div class="panel-body" style="padding: 0; max-height: 490px; overflow-y: auto;">
                    <?php if (empty($createdPackages)): ?>
                        <div style="padding: 20px; text-align: center;" class="text-muted">No provisioning packages have been generated yet.</div>
                    <?php else: ?>
                        <table class="table table-striped table-bordered" style="margin-bottom: 0; table-layout: fixed; width: 100%;">

<colgroup>
        <col style="width: 100px;"> <!-- Locks Left Cell (Extension) -->
        <col style="width: 160px;">  <!-- Right Cell fills remaining space (MAC) -->
        <col style="width: auto;"> <!-- Date Created -->
        <col style="width: 165px;"> <!-- Actions -->
    </colgroup>

                            <thead>
                                <tr>
                                    <th colspan="2" style="text-align: center;">Extension</th>
                                    <th style="width: auto; text-align: center;">Date Created</th>
                                    <th style="width: 130px; text-align: center;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
<?php foreach ($createdPackages as $pkgPath):
    $filename = basename($pkgPath);
    $downloadUrl = "/PhoneSettings/vpnkeys/" . rawurlencode($filename);
    
    // Split filename by underscores
    $parts = explode('_', $filename);
    $pkgExt = '';
    $pkgMac = '';

    // Standard naming format: {MAC}_{EXT}_{TOKEN}_ovpn.tar or {MAC}_{EXT}_ovpn.tar
    if (count($parts) >= 3 && end($parts) === 'ovpn.tar' || strpos($filename, '_ovpn.tar') !== false) {
        $pkgMac = strtoupper($parts[0]);
        $pkgExt = $parts[1];
    } else {
        // Fallback positional check
        $pkgMac = !empty($parts[0]) ? strtoupper($parts[0]) : '';
        $pkgExt = !empty($parts[1]) ? $parts[1] : '';
    }
?>
    <tr>
        <!-- Left Cell: Extension -->
        <td style="text-align: left; vertical-align: middle; font-size: 14px; cursor: default; padding-left: 15px; border-right: none;" 
            title="<?php echo htmlspecialchars($filename, ENT_QUOTES); ?>">
            <strong>
                <?php echo !empty($pkgExt) ? 'Ext. ' . htmlspecialchars($pkgExt) : '&mdash;'; ?>
            </strong>
        </td>

        <!-- Right Cell: MAC Address (Populates whatever string was saved) -->
        <td style="text-align: left; vertical-align: middle; font-size: 14px; cursor: default; padding-left: 5px; border-left: none;" 
            title="<?php echo htmlspecialchars($filename, ENT_QUOTES); ?>">
            <strong>
                <?php echo !empty($pkgMac) ? 'MAC: ' . htmlspecialchars($pkgMac) : '&mdash;'; ?>
            </strong>
        </td>

        <td style="text-align: center; vertical-align: middle; font-size: 12px;"><?php echo date("Y-m-d H:i", filemtime($pkgPath)); ?></td>
        <td style="text-align: center; vertical-align: middle; padding: 4px 2px;">
            <div style="display: flex; justify-content: center; align-items: center; gap: 3px;">
                <a href="<?php echo htmlspecialchars($downloadUrl); ?>" class="btn btn-xs btn-primary" download title="Download Package">
                    <i class="fa fa-download"></i>
                </a>
                <form method="post" action="config.php?display=ovpn_mgr" style="display:inline;">
                    <input type="hidden" name="action" value="delete_package">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                    <input type="hidden" name="pkg" value="<?php echo htmlspecialchars($filename); ?>">
                    <button type="submit" class="btn btn-xs btn-danger" title="Delete Package & Revoke Keys" data-confirm-message="Delete package and REVOKE extension keys? This action cannot be undone.">
                        <i class="fa fa-trash"></i>
                    </button>
                </form>
            </div>
        </td>
    </tr>
<?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Hidden form used by the bulk Download/Revoke Selected buttons above -->
<form id="bulkPkgForm" method="post" action="config.php?display=ovpn_mgr" style="display:none;">
    <input type="hidden" name="action" id="bulkPkgAction" value="">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
    <div id="bulkPkgInputs"></div>
</form>

<!-- Modal: Sign Module (no password needed - kept only for consistency) -->
<div class="modal fade" id="signModal" tabindex="-1" role="dialog" aria-labelledby="signModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="post" action="config.php?display=ovpn_mgr" id="signModalForm">
                <input type="hidden" name="action" value="resign_custom_module_with_pass">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="signModalLabel"><i class="fa fa-key"></i> Sign Module</h4>
                </div>
                <div class="modal-body">
                    <p>This re-hashes the module's own files and clears the tamper/signature warning for <code>ovpn_mgr</code>. No root privilege is required for this step.</p>
                    <div id="signProgressContainer" style="display: none; margin-top: 15px;">
                        <label><i class="fa fa-spinner fa-spin"></i> Signing module and reloading framework... Please wait.</label>
                        <div class="progress progress-striped active" style="margin-bottom: 0;">
                            <div class="progress-bar progress-bar-danger" role="progressbar" style="width: 100%;"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" id="signCancelBtn">Cancel</button>
                    <button type="submit" class="btn btn-danger" id="signSubmitBtn"><i class="fa fa-key"></i> Sign Module</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Revocation -->
<div class="modal fade" id="revokeModal" tabindex="-1" role="dialog" aria-labelledby="revokeModalLabel">
    <div class="modal-dialog modal-lg" role="document" style="width: 90%; max-width: 950px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="revokeModalLabel"><i class="fa fa-key"></i> Manage / Revoke Keys & Provisioning Packages</h4>
            </div>
            <?php if (!empty($issuedCertFiles)): ?>
                <div style="padding: 6px 10px; border-bottom: 1px solid #ddd; display: flex; align-items: center; gap: 6px; background: #f8f9fa;">
                    <span id="pkgSelectedCount" class="text-muted" style="font-size: 11px;">Select rows with a package to enable Download / Revoke Selected below.</span>
                </div>
            <?php endif; ?>
            <div class="modal-body" style="padding: 0;">
                <?php if (empty($issuedCertFiles)): ?>
                    <div style="padding: 20px;" class="text-muted">No issued client certificates found in PKI storage.</div>
                <?php else: ?>
                    <!-- Fixed to ~10 rows (thead ~41px + 10 * ~42px row height); the
                         rest scrolls. Header stays pinned via position:sticky so
                         columns stay labeled while scrolling. -->
                    <div style="max-height: 461px; overflow-y: auto;">
                        <table class="table table-striped table-bordered" style="margin-bottom: 0;">
                            <thead>
                                <tr>
                                    <th style="width: 26px; text-align: center; position: sticky; top: 0; background: #d6e4dd; z-index: 1;">
                                        <input type="checkbox" id="pkgSelectAll" title="Select all (rows with a package only)" onchange="toggleAllOvpnPkgCheckboxes(this)">
                                    </th>
                                    <th style="position: sticky; top: 0; background: #d6e4dd; z-index: 1;">Common Name (Ext)</th>
                                    <th style="position: sticky; top: 0; background: #d6e4dd; z-index: 1;">Target (Host:Port)</th>
                                    <th style="position: sticky; top: 0; background: #d6e4dd; z-index: 1;">Issued Date</th>
                                    <th style="position: sticky; top: 0; background: #d6e4dd; z-index: 1;">Package</th>
                                    <th style="width: 150px; text-align: center; position: sticky; top: 0; background: #d6e4dd; z-index: 1;">Revocation</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($issuedCertFiles as $crtPath):
                                    $extName = pathinfo($crtPath, PATHINFO_FILENAME);
                                    $parsedCert = openssl_x509_parse((string)@file_get_contents($crtPath));
                                    $validFrom = date("Y-m-d H:i", $parsedCert['validFrom_time_t'] ?? filemtime($crtPath));
                                    $targetHostPort = "{$currentServerIp}:{$currentPort}";
                                    $matchingTars = glob("{$pkgDir}/*_{$extName}_*_ovpn.tar");
                                    if (empty($matchingTars)) { $matchingTars = glob("{$pkgDir}/*_{$extName}_ovpn.tar"); }
                                    $pkgFilename = null;
                                    if (!empty($matchingTars[0]) && file_exists($matchingTars[0])) {
                                        $pkgFilename = basename($matchingTars[0]);
                                        $cnfOutput = shell_exec("tar -xOf " . escapeshellarg($matchingTars[0]) . " vpn.cnf 2>/dev/null");
                                        if (!empty($cnfOutput) && preg_match('/^remote\s+([^\s]+)\s+(\d+)/m', $cnfOutput, $mRemote)) {
                                            $targetHostPort = "{$mRemote[1]}:{$mRemote[2]}";
                                        }
                                    }
                                ?>
                                    <tr>
                                        <td style="text-align: center; vertical-align: middle;">
                                            <?php if ($pkgFilename !== null): ?>
                                                <input type="checkbox" class="ovpn-pkg-checkbox" value="<?php echo htmlspecialchars($pkgFilename, ENT_QUOTES); ?>" onchange="updateOvpnPkgSelection()">
                                            <?php endif; ?>
                                        </td>
                                        <td><strong>Extension <?php echo htmlspecialchars($extName); ?></strong></td>
                                        <td><code><?php echo htmlspecialchars($targetHostPort); ?></code></td>
                                        <td><?php echo htmlspecialchars($validFrom); ?></td>
                                        <td style="font-size: 12px;">
                                            <?php if ($pkgFilename !== null): ?>
                                                <code style="color: #08096e;"><?php echo htmlspecialchars($pkgFilename); ?></code>
                                            <?php else: ?>
                                                <span class="text-muted">&mdash; no package built</span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align: center;">
                                            <form method="post" action="config.php?display=ovpn_mgr" style="display:inline;">
                                                <input type="hidden" name="action" value="revoke_cert">
                                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                                                <input type="hidden" name="revoke_ext" value="<?php echo htmlspecialchars($extName); ?>">
                                                <button type="submit" class="btn btn-xs btn-danger" data-confirm-message="REVOKE Extension <?php echo htmlspecialchars($extName, ENT_QUOTES); ?>? This will block the phone from connecting and update the CRL."><i class="fa fa-ban"></i> Revoke & Block</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer" style="display: flex; justify-content: flex-start; gap: 6px; flex-wrap: wrap;">
                <button type="button" style="height:30px;" id="pkgDownloadSelectedBtn" class="btn btn-primary btn-sm" disabled onclick="submitOvpnBulkPkgAction('bulk_download_packages')">
                    <i class="fa fa-download"></i> Download Selected
                </button>
                <button type="button" id="pkgRevokeSelectedBtn" class="btn btn-danger btn-sm" disabled onclick="submitOvpnBulkPkgAction('bulk_revoke_packages')">
                    <i class="fa fa-ban"></i> Revoke Selected
                </button>
                <button type="button" id="pkgRebuildSelectedBtn" class="btn btn-warning btn-sm" disabled onclick="submitOvpnBulkPkgAction('bulk_revoke_rebuild_packages')">
                    <i class="fa fa-refresh"></i> Revoke & Rebuild Selected
                </button>
                <span style="flex: 1 1 auto;"></span>
                <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal: Log Viewer -->
<div class="modal fade" id="logModal" tabindex="-1" role="dialog" aria-labelledby="logModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="logModalLabel"><i class="fa fa-terminal"></i> OpenVPN Live Log Output (Last 200 Lines)</h4>
            </div>
            <div class="modal-body">
                <textarea id="logModalPre" readonly style="width: 100%; height: 350px; min-height: 200px; resize: both; overflow: auto; background: #f4f4f4; color: #111111; font-family: monospace; font-size: 12px; border: 1px solid #ccc; border-radius: 4px; padding: 10px;"><?php echo !empty($logContent) ? htmlspecialchars($logContent) : 'No log output available.'; ?></textarea>
            </div>
            <div class="modal-footer" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 5px;">
                <div style="display: flex; gap: 5px;">
                    <button type="button" class="btn btn-primary btn-sm" onclick="copyLogContent()"><i class="fa fa-copy"></i> Copy Log</button>
                    <button type="button" class="btn btn-info btn-sm" onclick="addLogPageBreak()"><i class="fa fa-minus"></i> Add Line Break</button>
                </div>
                <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Generic "please wait" progress modal for actions that take a few
     seconds (start/stop/save/revoke/bulk actions). These are plain form
     POSTs that redirect on completion (no AJAX progress %), so this is
     shown right before the form submits and stays up until the page
     navigates away. -->
<div class="modal fade ovpn-vcenter" id="ovpnProgressModal" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog" role="document" style="width: 360px;">
        <div class="modal-content" style="text-align: center; padding: 28px 24px;">
            <div class="progress" style="height: 20px; margin-bottom: 14px; border-radius: 4px; background-color: #e9ecef; overflow: hidden;">
                <div class="progress-bar progress-bar-striped active" role="progressbar" style="width: 100%; background-color: #007bff;"></div>
            </div>
            <div id="ovpnProgressLabel" style="font-weight: 600; font-size: 13px; color: #555;">Working, please wait...</div>
        </div>
    </div>
</div>

<style>
/* Bootstrap 3 has no built-in vertical centering for modals - this
   centers the dialog in the viewport instead of it appearing pinned
   near the top, and applies to the confirm modal + progress modal. */
.modal.ovpn-vcenter {
    text-align: center;
    padding: 0 !important;
}
.modal.ovpn-vcenter:before {
    content: '';
    display: inline-block;
    height: 100%;
    vertical-align: middle;
    margin-right: -4px;
}
.modal.ovpn-vcenter .modal-dialog {
    display: inline-block;
    text-align: left;
    vertical-align: middle;
    margin: 0 auto;
}
/* Wider, shorter "16:9-ish" proportions instead of the default narrow/
   tall modal-sm box, per request. */
#ovpnConfirmModal .modal-dialog {
    width: 480px;
}
#ovpnConfirmModal .modal-body {
    padding: 30px 28px !important;
    font-size: 14px;
    display: flex;
    align-items: center;
    min-height: 90px;
}
</style>

<script>
var OVPN_CSRF = <?php echo json_encode($csrfToken); ?>;

function showOvpnProgress(label) {
    $('#ovpnProgressLabel').text(label || 'Working, please wait...');
    $('#ovpnProgressModal').modal('show');
}

function ipToLong(ip) {
    var parts = ip.split('.');
    if (parts.length !== 4) return 0;
    return parts.reduce(function(acc, octet) { return (acc << 8) + parseInt(octet, 10); }, 0) >>> 0;
}
function longToIp(long) {
    return [(long >>> 24) & 255, (long >>> 16) & 255, (long >>> 8) & 255, long & 255].join('.');
}
function cidrToNetmaskJs(cidr) {
    cidr = parseInt(cidr) || 24;
    if (cidr < 16) cidr = 16;
    if (cidr > 29) cidr = 29;
    var mask = (0xFFFFFFFF << (32 - cidr)) >>> 0;
    return longToIp(mask);
}
function recalculateRange() {
    var hostIp = $('#ovpn_host_ip').val().trim();
    var cidr = parseInt($('#ovpn_cidr').val()) || 24;
    if (cidr < 16) cidr = 16;
    if (cidr > 29) cidr = 29;
    var netmask = cidrToNetmaskJs(cidr);
    var longHost = ipToLong(hostIp);
    var longMask = ipToLong(netmask);
    var $notice = $('#host_ip_live_notice');

    // Usable client IPs: total host addresses minus network + broadcast,
    // minus 1 more for the address OpenVPN's "server" directive always
    // reserves for itself.
    var clientIpCount = Math.max(0, (Math.pow(2, 32 - cidr) - 2) - 1);
    $('#client_ip_count').text(clientIpCount);

    var octets = hostIp.split('.');
    var looksLikeIp = octets.length === 4 && octets.every(function(o) {
        return /^\d{1,3}$/.test(o) && parseInt(o, 10) <= 255;
    });

    if (!looksLikeIp || longHost === 0 || longMask === 0) {
        $('#range_start').text('10.8.0.1'); $('#range_end').text('10.8.0.254');
        if (hostIp.length > 0) {
            $notice.text('This does not look like a valid IPv4 address.')
                .css({ display: 'block', background: '#f2dede', color: '#a94442', border: '1px solid #ebccd1' });
        } else {
            $notice.hide();
        }
        return;
    }
    var longNet = (longHost & longMask) >>> 0;
    var broadcastLong = (longNet | (~longMask & 0xFFFFFFFF)) >>> 0;
    var firstUsableLong = longNet + 1;
    var lastUsableLong = broadcastLong - 1;
    $('#range_start').text(longToIp(firstUsableLong));
    $('#range_end').text(longToIp(lastUsableLong));

    if (longHost !== (firstUsableLong >>> 0)) {
        var isNetOrBcast = (longHost === longNet) || (longHost === broadcastLong);
        var reason = isNetOrBcast
            ? 'that is the network/broadcast address of this block, not a usable host'
            : 'OpenVPN\'s "server" directive always assigns itself the first usable address of the subnet';
        $notice.html('<i class="fa fa-info-circle"></i> This will be saved as <code>' + longToIp(firstUsableLong) + '</code> instead - ' + reason + '.')
            .css({ display: 'block', background: '#fcf8e3', color: '#8a6d3b', border: '1px solid #faebcc' });
    } else {
        $notice.hide();
    }
}

$(document).ready(function() {
    $('[data-toggle="popover"]').popover();
    recalculateRange();
});

$('#signModalForm').on('submit', function(e) {
    e.preventDefault();
    $('#signProgressContainer').show();
    $('#signSubmitBtn').prop('disabled', true).html('<i class="fa fa-spinner fa-spin"></i> Signing...');
    $('#signCancelBtn').prop('disabled', true);
    $.ajax({
        url: 'config.php?display=ovpn_mgr', type: 'POST', data: $(this).serialize(), dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                $('#signModal').modal('hide');
                setTimeout(function() { window.location.reload(); }, 400);
            } else {
                showOvpnToast('Signing failed: ' + (response.message || 'Unknown error'));
                $('#signProgressContainer').hide();
                $('#signSubmitBtn').prop('disabled', false).html('<i class="fa fa-key"></i> Sign Module');
                $('#signCancelBtn').prop('disabled', false);
            }
        },
        error: function() {
            showOvpnToast('An error occurred during communication with the server.');
            $('#signProgressContainer').hide();
            $('#signSubmitBtn').prop('disabled', false).html('<i class="fa fa-key"></i> Sign Module');
            $('#signCancelBtn').prop('disabled', false);
        }
    });
});

function setPrivateIp() {
    $('#server_ip').val(<?php echo json_encode($_SERVER['SERVER_ADDR'] ?? ''); ?>);
}
function fetchPublicIp() {
    $('#server_ip').val('Fetching...');
    $.get('config.php?display=ovpn_mgr&action=fetch_public_ip', function(ip) {
        $('#server_ip').val(ip.trim());
    }).fail(function() {
        $('#server_ip').val(<?php echo json_encode($_SERVER['SERVER_ADDR'] ?? ''); ?>);
    });
}
function showOvpnToast(message) {
    var $toast = $('#ovpnToast');
    if ($toast.length === 0) {
        $toast = $('<div id="ovpnToast"></div>').css({
            position: 'fixed', bottom: '20px', right: '20px', zIndex: 9999,
            background: '#333', color: '#fff', padding: '10px 16px',
            borderRadius: '4px', fontSize: '13px', boxShadow: '0 2px 8px rgba(0,0,0,0.3)',
            opacity: 0, transition: 'opacity 0.3s ease'
        }).appendTo('body');
    }
    if ($toast.data('timeout')) { clearTimeout($toast.data('timeout')); }
    $toast.text(message).css('opacity', 1);
    var t = setTimeout(function() { $toast.css('opacity', 0); }, 3000);
    $toast.data('timeout', t);
}

function copyLogContent() {
    var logTextarea = document.getElementById("logModalPre");
    logTextarea.select();
    logTextarea.setSelectionRange(0, 999999);
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(logTextarea.value).then(function() {
            showOvpnToast("Log output copied to clipboard");
        }).catch(function() { fallbackCopy(logTextarea); });
    } else {
        fallbackCopy(logTextarea);
    }
}
function fallbackCopy(element) {
    try {
        var successful = document.execCommand('copy');
        showOvpnToast(successful ? "Log output copied to clipboard" : "Failed to copy log text");
    } catch (err) {
        showOvpnToast("Browser does not support automatic copying");
    }
}

function copySetupCommand() {
    var text = document.getElementById('setupCmd').innerText;
    var done = function() { showOvpnToast('Command copied to clipboard'); };
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done).catch(function() {
            var ta = document.createElement('textarea');
            ta.value = text; document.body.appendChild(ta); ta.select();
            try { document.execCommand('copy'); done(); } catch (e) { showOvpnToast('Could not copy - please select and copy manually'); }
            document.body.removeChild(ta);
        });
    } else {
        var ta = document.createElement('textarea');
        ta.value = text; document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); done(); } catch (e) { showOvpnToast('Could not copy - please select and copy manually'); }
        document.body.removeChild(ta);
    }
}

// Shared confirmation modal for destructive actions. Deliberately not
// window.confirm(): Chrome (and others) offer a "Don't allow this page
// to ask again" checkbox on repeated native dialogs, and checking it
// makes every future confirm() call return false immediately with no
// visible dialog at all - silently blocking revoke/delete forever until
// the browser's per-site permission is reset by hand. A modal we render
// ourselves can't be suppressed that way.
function showOvpnConfirm(message, onConfirm) {
    var $modal = $('#ovpnConfirmModal');
    if ($modal.length === 0) {
        $modal = $(
            '<div class="modal fade ovpn-vcenter" id="ovpnConfirmModal" tabindex="-1" role="dialog">' +
            '<div class="modal-dialog" role="document"><div class="modal-content">' +
            '<div class="modal-body" id="ovpnConfirmMessage" style="padding:20px;"></div>' +
            '<div class="modal-footer" style="border-top:none; padding-top:0;">' +
            '<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Cancel</button>' +
            '<button type="button" class="btn btn-danger btn-sm" id="ovpnConfirmOkBtn">OK</button>' +
            '</div></div></div></div>'
        ).appendTo('body');
    }
    $('#ovpnConfirmMessage').text(message);
    $('#ovpnConfirmOkBtn').off('click').on('click', function() {
        $modal.modal('hide');
        onConfirm();
    });
    $modal.modal('show');
}

$(document).on('click', 'button[data-confirm-message], a[data-confirm-message]', function(e) {
    e.preventDefault();
    var $btn = $(this);
    var message = $btn.attr('data-confirm-message');
    var progressLabel = $btn.attr('data-progress-label') || 'Working, please wait...';
    var form = $btn.closest('form')[0];
    showOvpnConfirm(message, function() {
        if (form) {
            if ($btn.attr('name')) {
                $('<input>').attr({ type: 'hidden', name: $btn.attr('name'), value: $btn.attr('value') }).appendTo(form);
            }
            showOvpnProgress(progressLabel);
            form.submit();
        }
    });
});

// Non-destructive submits (Start/Restart service, Save Settings) don't go
// through the confirm modal above, but still take a few seconds - show
// the same progress overlay directly on submit.
$('#ovpnServiceForm').on('submit', function() {
    showOvpnProgress('Applying service command, please wait...');
});
$('#ovpnSettingsForm').on('submit', function() {
    showOvpnProgress('Saving settings and restarting the OpenVPN daemon...');
});

function toggleAllOvpnPkgCheckboxes(source) {
    $('.ovpn-pkg-checkbox').prop('checked', source.checked);
    updateOvpnPkgSelection();
}

function updateOvpnPkgSelection() {
    var $checked = $('.ovpn-pkg-checkbox:checked');
    var total = $('.ovpn-pkg-checkbox').length;
    $('#pkgDownloadSelectedBtn, #pkgRevokeSelectedBtn, #pkgRebuildSelectedBtn').prop('disabled', $checked.length === 0);
    $('#pkgSelectedCount').text($checked.length > 0 ? ($checked.length + ' selected') : '');
    $('#pkgSelectAll').prop('checked', total > 0 && $checked.length === total);
}

function submitOvpnBulkPkgAction(action) {
    var selected = $('.ovpn-pkg-checkbox:checked').map(function() { return this.value; }).get();
    if (selected.length === 0) {
        return;
    }

    var doSubmit = function() {
        var $inputs = $('#bulkPkgInputs').empty();
        selected.forEach(function(name) {
            $('<input>').attr({ type: 'hidden', name: 'pkgs[]', value: name }).appendTo($inputs);
        });
        $('#bulkPkgAction').val(action);
        if (action === 'bulk_revoke_packages') {
            showOvpnProgress('Revoking ' + selected.length + ' package(s), please wait...');
        } else if (action === 'bulk_revoke_rebuild_packages') {
            showOvpnProgress('Revoking and rebuilding ' + selected.length + ' package(s), please wait...');
        }
        document.getElementById('bulkPkgForm').submit();
    };

    if (action === 'bulk_revoke_packages') {
        showOvpnConfirm(
            'REVOKE and delete ' + selected.length + ' selected package(s)? This blocks those phones from ' +
            'connecting to the VPN and cannot be undone.',
            doSubmit
        );
    } else if (action === 'bulk_revoke_rebuild_packages') {
        showOvpnConfirm(
            'REVOKE and rebuild ' + selected.length + ' selected package(s) with the current server address? ' +
            'The old package(s) will stop working immediately and a fresh one will be issued in their place.',
            doSubmit
        );
    } else {
        doSubmit();
    }
}

let logInterval = null;
let isInitialOpen = false;

function fetchOpenVPNLog() {
    $.ajax({
        url: 'config.php', type: 'GET', data: { display: 'ovpn_mgr', action: 'fetch_log' },
        success: function(response) {
            const $textarea = $('#logModalPre');
            const elem = $textarea[0];
            const isAtBottom = (elem.scrollHeight - elem.clientHeight - elem.scrollTop) <= 40;
            $textarea.val(response);
            if (isInitialOpen || isAtBottom) {
                elem.scrollTop = elem.scrollHeight;
                isInitialOpen = false;
            }
        }
    });
}
function addLogPageBreak() {
    $.ajax({
        url: 'config.php', type: 'POST',
        data: { display: 'ovpn_mgr', action: 'add_page_break', csrf_token: OVPN_CSRF },
        success: function(response) {
            if (response.trim() === 'success') {
                isInitialOpen = true;
                fetchOpenVPNLog();
            } else {
                showOvpnToast("Failed to add line break.");
            }
        }
    });
}

$('#logModal').on('shown.bs.modal', function () {
    isInitialOpen = true;
    fetchOpenVPNLog();
    if (logInterval) clearInterval(logInterval);
    logInterval = setInterval(fetchOpenVPNLog, 2000);
});
$('#logModal').on('hidden.bs.modal', function () {
    if (logInterval) { clearInterval(logInterval); logInterval = null; }
});
</script>